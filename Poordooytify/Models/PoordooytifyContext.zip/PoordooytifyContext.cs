namespace Poordooytify.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class PoordooytifyContext : DbContext
    {
        public PoordooytifyContext()
            : base("name=PoordooytifyContext")
        {
        }

        public virtual DbSet<CloudToken> CloudTokens { get; set; }
        public virtual DbSet<Genre> Genres { get; set; }
        public virtual DbSet<Song> Songs { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
        }
    }
}
