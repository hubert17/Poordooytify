namespace Poordooytify.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Song
    {
        public int Id { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        public string Artist { get; set; }

        public string Genre { get; set; }

        public string OrigFilename { get; set; }

        public string Link { get; set; }

        public int CloudTokenId { get; set; }

        public DateTime DateAdded { get; set; }

        public string Moods { get; set; }

        public int PlayCount { get; set; }

        public Guid Key { get; set; }

        public virtual CloudToken CloudToken { get; set; }
    }
}
